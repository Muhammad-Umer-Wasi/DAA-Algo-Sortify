
// import { bubbleSort , insertionSort} from "../Algos/Algo.js";
import {bubbleSort, insertionSort, Heapsort, mergeSort, quickSort, countSort, radixSort, bucketSort, MQS} from "../Algos/Algo.js";
//Screen Settings
window.speedFactor = 200;
window.max = 10000;
window.heightFactor = (4 / max) * 100;
console.log("height", heightFactor);
window.bars = document.getElementsByClassName("bar");


let randomize_array = document.getElementById("randomize_array_btn");
let sort_btn = document.getElementById("sort_btn");
let bars_container = document.getElementById("bars_container");
let select_algo = document.getElementById("algo");
let slider = document.getElementById("slider");
let length_input = document.getElementById("length");
let out=document.getElementById("out")
let file_input = document.getElementById("file");
let algo = "";

let unsorted_array = new Array();

var numberArray= 0;
file_input.addEventListener("change", function () {
    let file = file_input.files[0];
    let reader = new FileReader();
    reader.addEventListener("load", function () {
        let buffer = reader.result.split(",");  ///\s+/
        numberArray = buffer.map(Number);
        console.log(numberArray);
        unsorted_array=numberArray;
    });
    reader.readAsText(file, "utf-8");
});

select_algo.addEventListener("change", function () {
    algo = select_algo.value;
});

select_algo.addEventListener("change", function () {
    if (select_algo.value === "range") {
        window.location = "range.html";
    } else algo = select_algo.value;
});

let time=document.getElementById("umer");


sort_btn.addEventListener("click", function () {
    
    let start,end;
    switch (algo) {
        case "bubble":
            
            // start = performance.now();
            start= performance.now().toPrecision(2)
            bubbleSort(unsorted_array,unsorted_array.length);
            end = performance.now().toPrecision(2);
            time.innerHTML = `${end - start} milliseconds`;
            out.innerHTML = "";
            out.innerHTML += `Sorted Array: ${unsorted_array}`;
            break;
        case "merge":
            
            start = performance.now();    
            mergeSort(unsorted_array, 0, unsorted_array.length - 1);
            end = performance.now();
            time.innerHTML = `${end - start} milliseconds`;
            out.innerHTML = "";
            out.innerHTML += `Sorted Array: ${unsorted_array}`;
            break;
        case "heap":
            start= performance.now().toPrecision(2)
            Heapsort(unsorted_array);
            end = performance.now().toPrecision(2);
            time.innerHTML = `Time: ${end - start} milliseconds`;
            out.innerHTML = "";
            out.innerHTML += `Sorted Array: ${unsorted_array}`;
            break;
        case "insertion": 
            start = performance.now();
            insertionSort(unsorted_array);
            end = performance.now();
            time.innerHTML = `Time: ${end - start} ms`;
            out.innerHTML = "";
            out.innerHTML += `Sorted Array: ${unsorted_array}`;
            break;
        case "quick":
            start = performance.now();
            quickSort(unsorted_array, 0, unsorted_array.length - 1);
            end = performance.now();
            time.innerHTML = `Time: ${end - start} ms`;
            out.innerHTML = "";
            out.innerHTML += `Sorted Array: ${unsorted_array}`;
            break;
        case "count":
            start = performance.now();
            countSort(unsorted_array);
            end = performance.now();
            time.innerHTML = `Time: ${end - start} ms`;
            out.innerHTML = "";
            out.innerHTML += `Sorted Array: ${unsorted_array}`;
            break;
        case "radix":
            start = performance.now();
            radixSort(unsorted_array, unsorted_array.length);
            end = performance.now();
            time.innerHTML = `Time: ${end - start} ms`;
            out.innerHTML = "";
            out.innerHTML += `Sorted Array: ${unsorted_array}`;
            break;
        case "bucket":
            start = performance.now();
            bucketSort(numberArray);
            end = performance.now();
            console.log(unsorted_array)
            time.innerHTML = `Time: ${end - start} ms`;
            out.innerHTML = "";
            out.innerHTML += `Sorted Array: ${unsorted_array}`;
            break;
        case "MQS":
            start = performance.now();
            MQS(unsorted_array, 0, unsorted_array.length - 1);
            end = performance.now()
            time.innerHTML = `Time: ${end - start} ms`;
            out.innerHTML = "";
            out.innerHTML += `Sorted Array: ${unsorted_array}`;
            break;
        default:
            bubbleSort(numberArray);
            break;
    }
});