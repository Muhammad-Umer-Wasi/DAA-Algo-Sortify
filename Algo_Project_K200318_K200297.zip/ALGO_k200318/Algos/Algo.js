//Bubble Sort
export function bubbleSort(inputArr,len){
        
    for (let i = 0; i < len; i++) {
        for (let j = 0; j < len; j++) {
            if (inputArr[j] > inputArr[j + 1]) {
                let tmp = inputArr[j];
                inputArr[j] = inputArr[j + 1];
                inputArr[j + 1] = tmp;
            }
        }
    }
            
    return inputArr;
};
    

   //Insertion Sort
   export async function insertionSort(inputArr) {
    
    let n = inputArr.length;
        for (let i = 1; i < n; i++) {
            // Choosing the first element in our unsorted subarray
            let current = inputArr[i];
            // The last element of our sorted subarray
            let j = i-1; 
            while ((j > -1) && (current < inputArr[j])) {
                inputArr[j+1] = inputArr[j];
                j--;
            }
            inputArr[j+1] = current;
        }
    

        return inputArr;
}


//Heap Sort
export function Heapsort( arr)
{
    var N = arr.length;

    // Build heap (rearrange array)
    for (var i = Math.floor(N / 2) - 1; i >= 0; i--)
        heapify(arr, N, i);

    // One by one extract an element from heap
    for (var i = N - 1; i > 0; i--) {
        // Move current root to end
        var temp = arr[0];
        arr[0] = arr[i];
        arr[i] = temp;

        // call max heapify on the reduced heap
        heapify(arr, i, 0);
    }
    return arr;
}

// To heapify a subtree rooted with node i which is
// an index in arr[]. n is size of heap
function heapify(arr, N, i)
{
    var largest = i; // Initialize largest as root
    var l = 2 * i + 1; // left = 2*i + 1
    var r = 2 * i + 2; // right = 2*i + 2

    // If left child is larger than root
    if (l < N && arr[l] > arr[largest])
        largest = l;

    // If right child is larger than largest so far
    if (r < N && arr[r] > arr[largest])
        largest = r;

    // If largest is not root
    if (largest != i) {
        var swap = arr[i];
        arr[i] = arr[largest];
        arr[largest] = swap;

        // Recursively heapify the affected sub-tree
        heapify(arr, N, largest);
    }
    return arr;
}

//Merge Sort
function merge(arr, l, m, r)
{
    var n1 = m - l + 1;
    var n2 = r - m;
 
    // Create temp arrays
    var L = new Array(n1);
    var R = new Array(n2);
 
    // Copy data to temp arrays L[] and R[]
    for (var i = 0; i < n1; i++)
        L[i] = arr[l + i];
    for (var j = 0; j < n2; j++)
        R[j] = arr[m + 1 + j];
 
    // Merge the temp arrays back into arr[l..r]
 
    // Initial index of first subarray
    var i = 0;
 
    // Initial index of second subarray
    var j = 0;
 
    // Initial index of merged subarray
    var k = l;
 
    while (i < n1 && j < n2) {
        if (L[i] <= R[j]) {
            arr[k] = L[i];
            i++;
        }
        else {
            arr[k] = R[j];
            j++;
        }
        k++;
    }
 
    // Copy the remaining elements of
    // L[], if there are any
    while (i < n1) {
        arr[k] = L[i];
        i++;
        k++;
    }
 
    // Copy the remaining elements of
    // R[], if there are any
    while (j < n2) {
        arr[k] = R[j];
        j++;
        k++;
    }
}
 
// l is for left index and r is
// right index of the sub-array
// of arr to be sorted */
export function mergeSort(arr,l, r){
    if(l>=r){
        return;//returns recursively
    }
    var m =l+ parseInt((r-l)/2);
    mergeSort(arr,l,m);
    mergeSort(arr,m+1,r);
    merge(arr,l,m,r);
}

//QuickSort
function swap(arr, i, j) {
    let temp = arr[i];
    arr[i] = arr[j];
    arr[j] = temp;
}
  
/* This function takes last element as pivot, places
   the pivot element at its correct position in sorted
   array, and places all smaller (smaller than pivot)
   to left of pivot and all greater elements to right
   of pivot */
function partition(arr, low, high) {
  
    // pivot
    let pivot = arr[high];
  
    // Index of smaller element and
    // indicates the right position
    // of pivot found so far
    let i = (low - 1);
  
    for (let j = low; j <= high - 1; j++) {
  
        // If current element is smaller 
        // than the pivot
        if (arr[j] < pivot) {
  
            // Increment index of 
            // smaller element
            i++;
            swap(arr, i, j);
        }
    }
    swap(arr, i + 1, high);
    return (i + 1);
}
  

export function quickSort(arr, low, high) {
    if (low < high) {
  
        let pi = partition(arr, low, high);
        quickSort(arr, low, pi - 1);
        quickSort(arr, pi + 1, high);
    }
    return arr;
}

//count sort
export function countSort(inputArr){
    var n = inputArr.length
    let k = Math.max(...inputArr);
    let t;
    //Create a temporary with 0 zero value 
    //as the same length of max elemet + 1
    const temp = new Array(k + 1).fill(0);
    
    //Count the frequency of each element in the original array
    //And store it in temp array
    for(let i = 0; i < n; i++){
      t = inputArr[i];
      temp[t]++;
    }
  
    //Update the count based on the previous index
    for(let i = 1; i <= k; i++){
      // Updating elements of count array 
      temp[i] = temp[i] + temp[i - 1];  
    }
    
    //Output arr
    const outputArr = new Array(n).fill(0);
    
    for(let i = n - 1; i >= 0; i--) {
      // Add elements of array A to array B
      t = inputArr[i];
      outputArr[temp[t] - 1] = t;  
          
      // Decrement the count value by 1
      temp[t] = temp[t] - 1;		
     }
    
    return outputArr;
  }
// const countingSortNegative = (arr, n = arr.length) => {
//   let max = Math.max(...arr);
//   let min = Math.min(...arr);
//   let range = max - min + 1;
//   let count = new Array(range).fill(0);
//   let output = new Array(n).fill(0);
  
//   //Store the frequency
//   for (let i = 0; i < n; i++) { 
//     count[arr[i] - min]++; 
//   } 
 
//   //Accumulate the frequency
//   for (let i = 1; i < count.length; i++) { 
//     count[i] += count[i - 1]; 
//   } 
  
//   //Sort based on frequency
//   for (let i = n - 1; i >= 0; i--) { 
//     output[count[arr[i] - min] - 1] = arr[i]; 
//     count[arr[i] - min]--; 
//   } 
  
//   return output;
// }

//radix sort
function getMax(arr,n)
{
    let mx = arr[0];
        for (let i = 1; i < n; i++)
            if (arr[i] > mx)
                mx = arr[i];
        return mx;
}
 
// A function to do counting sort of arr[] according to
    // the digit represented by exp.
function countSorter(arr,n,exp)
{
    let output = new Array(n); // output array
        let i;
        let count = new Array(10);
        for(let i=0;i<10;i++)
            count[i]=0;
  
        // Store count of occurrences in count[]
        for (i = 0; i < n; i++)
            count[Math.floor(arr[i] / exp) % 10]++;
  
        // Change count[i] so that count[i] now contains
        // actual position of this digit in output[]
        for (i = 1; i < 10; i++)
            count[i] += count[i - 1];
  
        // Build the output array
        for (i = n - 1; i >= 0; i--) {
            output[count[Math.floor(arr[i] / exp) % 10] - 1] = arr[i];
            count[Math.floor(arr[i] / exp) % 10]--;
        }
  
        // Copy the output array to arr[], so that arr[] now
        // contains sorted numbers according to current digit
        for (i = 0; i < n; i++)
            arr[i] = output[i];
}
 
// The main function to that sorts arr[] of size n using
    // Radix Sort
export function radixSort(arr,n)
{
    // Find the maximum number to know number of digits
        let m = getMax(arr, n);
  
        // Do counting sort for every digit. Note that
        // instead of passing digit number, exp is passed.
        // exp is 10^i where i is current digit number
        for (let exp = 1; Math.floor(m / exp) > 0; exp *= 10)
            countSorter(arr, n, exp);
}

//Bucket Sort
async function insertionSorter(array) {
    var length = array.length;

    for (var i = 1; i < length; i++) {
        var temp = array[i];
        for (var j = i - 1; j >= 0 && array[j] > temp; j--) {
            array[j + 1] = array[j];
        }
        array[j + 1] = temp;
    }
}

export async function bucketSort(array, bucketSize) {
    if (array.length === 0) {
        return array;
    }

    var i,
        minValue = array[0],
        maxValue = array[0],
        bucketSize = bucketSize || 5;

    array.forEach(function (currentVal) {
        if (currentVal < minValue) {
            minValue = currentVal;
        } else if (currentVal > maxValue) {
            maxValue = currentVal;
        }
    });

    var bucketCount = Math.floor((maxValue - minValue) / bucketSize) + 1;
    var allBuckets = new Array(bucketCount);

    for (i = 0; i < allBuckets.length; i++) {
        allBuckets[i] = [];
    }
    array.forEach(function (currentVal) {
        allBuckets[Math.floor((currentVal - minValue) / bucketSize)].push(
            currentVal
        );
    });

    
    return array;
}

//Modified quick
async function partitioner(arr, low, high) {
    let pivot = arr[high];
    let i = low - 1;
    for (let j = low; j <= high - 1; j++) {
        if (arr[j] < pivot) {
            i++;
            await swap(arr, i, j);
        }
    }
    await swap(arr, i + 1, high);
}
async function quickSorter(arr, low, high) {
    let k = 8;
    if (low < high && high - low > k) {
        let pi = await partitioner(arr, low, high);
        await quickSorter(arr, low, pi - 1);
        await quickSorter(arr, pi + 1, high);
    }
}
export async function MQS(arr, low, high) {
    await quickSorter(arr, low, high);
    insertionSort(arr);
    return arr;
}

